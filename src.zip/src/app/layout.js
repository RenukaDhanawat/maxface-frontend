import './globals.css'
import ChatBot from '@/components/common/ChatBot'

export const metadata = {
  title: 'MaxFace Dental Clinic | Premium Dental Care',
  description: 'Expert dental treatments including implants, root canal, teeth whitening and more.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
        <ChatBot />
      </body>
    </html>
  )
}