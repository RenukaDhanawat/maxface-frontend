import Navbar from '@/components/common/Navbar'
import Footer from '@/components/common/Footer'
import Image from 'next/image'

export default function DoctorsPage() {

const doctors = [

{
name: "Dr. Mahantesh",
image: "/mahantesh.jpg",
role: "Periodontist & Implantologist",
about: "Dr. Mahantesh is a Periodontist and Implantologist and Fellow of the International Congress of Oral Implantologists (USA). He is a faculty member at ICOI Bangalore and serves on the editorial board of journals focused on advanced oral research. His interests include soft & hard tissue grafting, regenerative materials, implant complications, and implant maintenance."
},

{
name: "Dr. Dhanush",
image: "/dhanush.jpg",
role: "Maxillofacial Surgeon",
about: "Dr. Dhanush has extensive experience treating Oral Oncologic lesions and performing Microvascular Free Flap reconstruction for head and neck defects. His expertise includes mandibular and maxillary orthognathic surgery and aesthetic facial procedures. He is certified by ICOI for Nobel Biocare Zygoma implant placement."
},

{
name: "Dr. Naveen Raj",
image: "/naveen.png",
role: "Oral Implantologist",
about: "Dr. Naveen Raj holds a postgraduate diploma in Implantology from RGUHS, Bangalore. He is Fellow and Life Member of ISOI and Fellow & Diplomat of ICOI (USA) and BOCI (Sweden). He has helped many underprivileged patients receive free dental implant treatments and specializes in full mouth rehabilitation."
},

{
name: "Dr. B Srinivas Rao",
image: "/doctorphoto.jpg",
role: "Maxillofacial Prosthodontist & Implantologist",
about: "Dr. B Srinivas Rao is an academician and practitioner specializing in Maxillofacial Prosthetics and Implantology. He trained at Branemark Osseointegration Center, Sweden and holds fellowship from the International Congress of Oral Implantologists (USA). He is the Course Director at Maxface Implantology Academy."
},

{
name: "Dr. Deepak Kumar",
image: "/deepakkumar.jpg",
role: "Oral & Maxillofacial Surgeon",
about: "Dr. Deepak Kumar is a consultant oral and maxillofacial surgeon trained in oral oncology at Tata Memorial Cancer Centre, Mumbai. He is Fellow & Diplomat of BOCI India and Fellow of the International Congress of Oral Implantologists (USA). His expertise includes facial reconstruction with dental implants."
},

{
name: "Dr. Manish",
image: "/manish.png",
role: "Oral & Maxillofacial Surgeon",
about: "Dr. Manish specializes in implantology for complex full mouth rehabilitation and trauma surgery. He is a Fellow of the International Congress of Implantologists and trained at Branemark Osseointegration Center. He serves as a visiting consultant at Columbia Asia Hospital and multiple referral hospitals."
}

]

return (
<>
<Navbar />

{/* Hero */}

<section style={{
paddingTop:'140px',
paddingBottom:'80px',
textAlign:'center',
background:'linear-gradient(160deg,#F8FAFF,#EFF6FF)'
}}>

<h1 style={{
fontSize:'48px',
fontWeight:'800',
color:'#0F172A'
}}>
Our Doctors
</h1>

<p style={{
color:'#64748B',
fontSize:'18px'
}}>
Meet the specialists behind Maxface Dental Clinic
</p>

</section>

{/* Doctors List */}

<section style={{padding:'80px 24px'}}>

<div style={{
maxWidth:'1100px',
margin:'0 auto',
display:'flex',
flexDirection:'column',
gap:'60px'
}}>

{doctors.map((doc)=> (

<div key={doc.name} style={{
display:'grid',
gridTemplateColumns:'120px 1fr',
gap:'30px',
alignItems:'center'
}}>

<div style={{
width:'120px',
height:'120px',
borderRadius:'60px',
overflow:'hidden'
}}>

<Image
src={doc.image}
alt={doc.name}
width={120}
height={120}
style={{objectFit:'cover'}}
/>

</div>

<div>

<h3 style={{
fontSize:'20px',
fontWeight:'700',
color:'#0F172A'
}}>
{doc.name}
</h3>

<p style={{
color:'#1D4ED8',
fontWeight:'600',
marginBottom:'10px'
}}>
{doc.role}
</p>

<p style={{
color:'#475569',
lineHeight:'1.7'
}}>
{doc.about}
</p>

</div>

</div>

))}

</div>

</section>

<Footer />

</>
)
}