'use client'
import { useState } from 'react'
import Navbar from '@/components/common/Navbar'
import Footer from '@/components/common/Footer'

const treatments = [
  'Teeth Cleaning', 'Root Canal', 'Dental Implants',
  'Smile Makeover', 'Teeth Whitening', 'Braces & Aligners',
  'Gum Treatment', 'Wisdom Tooth Removal', 'Pediatric Dentistry'
]

const timeSlots = [
  '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM',
  '11:00 AM', '11:30 AM', '12:00 PM', '2:00 PM',
  '2:30 PM', '3:00 PM', '3:30 PM', '4:00 PM',
  '4:30 PM', '5:00 PM', '5:30 PM', '6:00 PM',
]

export default function AppointmentPage() {
  const [form, setForm] = useState({
    patientName:'', phone:'', email:'',
    treatmentType:'', date:'', timeSlot:'', notes:''
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading,   setLoading]   = useState(false)

  const handleChange = (e) => setForm({...form, [e.target.name]: e.target.value})

  const handleSubmit = async () => {
    if (!form.patientName || !form.phone || !form.email || !form.treatmentType || !form.date || !form.timeSlot) {
      alert('Please fill all required fields!')
      return
    }
    setLoading(true)
    try {
      const response = await fetch('http://localhost:5000/api/appointments', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify(form)
      })
      const data = await response.json()
      if (data.success) {
        setSubmitted(true)
      } else {
        alert('Something went wrong. Please try again!')
      }
    } catch (error) {
      alert('Cannot connect to server. Please try again!')
    }
    setLoading(false)
  }

  if (submitted) {
    return (
      <>
        <Navbar />
        <div style={{minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'#F8FAFF', paddingTop:'80px'}}>
          <div style={{textAlign:'center', padding:'60px', background:'white', borderRadius:'24px', boxShadow:'0 20px 60px rgba(0,0,0,0.08)', maxWidth:'500px'}}>
            <div style={{fontSize:'80px', marginBottom:'24px'}}>🎉</div>
            <h2 style={{fontSize:'28px', fontWeight:'800', color:'#1A1A2E', marginBottom:'12px'}}>Appointment Booked!</h2>
            <p style={{color:'#6B7280', fontSize:'16px', lineHeight:'1.7', marginBottom:'8px'}}>
              Thank you, <strong>{form.patientName}</strong>!
            </p>
            <p style={{color:'#6B7280', fontSize:'16px', lineHeight:'1.7', marginBottom:'8px'}}>
              Your appointment for <strong>{form.treatmentType}</strong> is scheduled on <strong>{form.date}</strong> at <strong>{form.timeSlot}</strong>.
            </p>
            <p style={{color:'#6B7280', fontSize:'14px', marginBottom:'32px'}}>
              We'll send a confirmation to <strong>{form.email}</strong> shortly.
            </p>
            <button
              onClick={() => { setSubmitted(false); setForm({patientName:'', phone:'', email:'', treatmentType:'', date:'', timeSlot:'', notes:''}) }}
              style={{background:'linear-gradient(135deg, #3B9EFF, #2563EB)', color:'white', padding:'14px 32px', borderRadius:'50px', border:'none', fontWeight:'600', fontSize:'15px', cursor:'pointer'}}
            >
              Book Another Appointment
            </button>
          </div>
        </div>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Navbar />
      <div style={{minHeight:'100vh', background:'#F8FAFF', paddingTop:'100px', paddingBottom:'80px'}}>
        <div style={{maxWidth:'800px', margin:'0 auto', padding:'0 24px'}}>

          {/* Header */}
          <div style={{textAlign:'center', marginBottom:'48px'}}>
            <div style={{display:'inline-block', background:'#DBEAFE', color:'#3B9EFF', padding:'6px 16px', borderRadius:'20px', fontSize:'14px', fontWeight:'500', marginBottom:'16px'}}>
              Book Appointment
            </div>
            <h1 style={{fontSize:'clamp(28px, 4vw, 48px)', fontWeight:'800', color:'#1A1A2E', marginBottom:'12px'}}>
              Schedule Your Visit
            </h1>
            <p style={{color:'#6B7280', fontSize:'16px'}}>
              Fill in the details below and we'll confirm your appointment shortly.
            </p>
          </div>

          {/* Form Card */}
          <div style={{background:'white', borderRadius:'24px', padding:'40px', boxShadow:'0 20px 60px rgba(0,0,0,0.08)'}}>

            {/* Row 1 */}
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'20px', marginBottom:'20px'}}>
              <div>
                <label style={{display:'block', fontSize:'14px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Full Name *</label>
                <input
                  name="patientName" value={form.patientName} onChange={handleChange}
                  placeholder="Enter your full name"
                  style={{width:'100%', padding:'12px 16px', borderRadius:'12px', border:'2px solid #E5E7EB', fontSize:'15px', outline:'none', boxSizing:'border-box'}}
                />
              </div>
              <div>
                <label style={{display:'block', fontSize:'14px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Phone Number *</label>
                <input
                  name="phone" value={form.phone} onChange={handleChange}
                  placeholder="+91 XXXXX XXXXX"
                  style={{width:'100%', padding:'12px 16px', borderRadius:'12px', border:'2px solid #E5E7EB', fontSize:'15px', outline:'none', boxSizing:'border-box'}}
                />
              </div>
            </div>

            {/* Row 2 */}
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'20px', marginBottom:'20px'}}>
              <div>
                <label style={{display:'block', fontSize:'14px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Email Address *</label>
                <input
                  name="email" value={form.email} onChange={handleChange}
                  placeholder="your@email.com"
                  style={{width:'100%', padding:'12px 16px', borderRadius:'12px', border:'2px solid #E5E7EB', fontSize:'15px', outline:'none', boxSizing:'border-box'}}
                />
              </div>
              <div>
                <label style={{display:'block', fontSize:'14px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Treatment Type *</label>
                <select
                  name="treatmentType" value={form.treatmentType} onChange={handleChange}
                  style={{width:'100%', padding:'12px 16px', borderRadius:'12px', border:'2px solid #E5E7EB', fontSize:'15px', outline:'none', boxSizing:'border-box', background:'white'}}
                >
                  <option value="">Select treatment</option>
                  {treatments.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>

            {/* Date */}
            <div style={{marginBottom:'20px'}}>
              <label style={{display:'block', fontSize:'14px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Preferred Date *</label>
              <input
                type="date" name="date" value={form.date} onChange={handleChange}
                min={new Date().toISOString().split('T')[0]}
                style={{width:'100%', padding:'12px 16px', borderRadius:'12px', border:'2px solid #E5E7EB', fontSize:'15px', outline:'none', boxSizing:'border-box'}}
              />
            </div>

            {/* Time Slots */}
            <div style={{marginBottom:'20px'}}>
              <label style={{display:'block', fontSize:'14px', fontWeight:'600', color:'#374151', marginBottom:'12px'}}>Preferred Time Slot *</label>
              <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(100px, 1fr))', gap:'10px'}}>
                {timeSlots.map(slot => (
                  <button key={slot} onClick={() => setForm({...form, timeSlot:slot})} style={{
                    padding:'10px', borderRadius:'10px', border:'2px solid',
                    borderColor: form.timeSlot === slot ? '#3B9EFF' : '#E5E7EB',
                    background: form.timeSlot === slot ? '#EFF6FF' : 'white',
                    color: form.timeSlot === slot ? '#3B9EFF' : '#6B7280',
                    fontWeight: form.timeSlot === slot ? '600' : '400',
                    fontSize:'13px', cursor:'pointer', transition:'all 0.2s'
                  }}>
                    {slot}
                  </button>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div style={{marginBottom:'32px'}}>
              <label style={{display:'block', fontSize:'14px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Additional Notes</label>
              <textarea
                name="notes" value={form.notes} onChange={handleChange}
                placeholder="Describe your dental concern..."
                rows={4}
                style={{width:'100%', padding:'12px 16px', borderRadius:'12px', border:'2px solid #E5E7EB', fontSize:'15px', outline:'none', resize:'vertical', boxSizing:'border-box'}}
              />
            </div>

            {/* Submit */}
            <button
              onClick={handleSubmit} disabled={loading}
              style={{
                width:'100%', padding:'16px',
                background: loading ? '#93C5FD' : 'linear-gradient(135deg, #3B9EFF, #2563EB)',
                color:'white', border:'none', borderRadius:'14px',
                fontSize:'16px', fontWeight:'700', cursor: loading ? 'not-allowed' : 'pointer'
              }}
            >
              {loading ? '⏳ Booking your appointment...' : '📅 Confirm Appointment'}
            </button>

          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}