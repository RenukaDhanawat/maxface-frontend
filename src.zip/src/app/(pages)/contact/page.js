'use client'
import { useState } from 'react'
import Navbar from '@/components/common/Navbar'
import Footer from '@/components/common/Footer'

export default function ContactPage() {
  const [form, setForm] = useState({ name:'', email:'', phone:'', message:'' })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => setForm({...form, [e.target.name]: e.target.value})

  const handleSubmit = async () => {
    if (!form.name || !form.email || !form.message) {
      alert('Please fill all required fields!')
      return
    }
    setLoading(true)
    try {
      const response = await fetch('http://localhost:5000/api/contact', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify(form)
      })
      const data = await response.json()
      if (data.success) {
        setSubmitted(true)
      } else {
        alert('Something went wrong!')
      }
    } catch (error) {
      alert('Cannot connect to server!')
    }
    setLoading(false)
  }

  return (
    <div>
      <Navbar />
      <div style={{minHeight:'100vh', background:'#F8FAFC', paddingTop:'100px', paddingBottom:'80px'}}>
        <div style={{maxWidth:'1280px', margin:'0 auto', padding:'0 24px'}}>

          <div style={{textAlign:'center', marginBottom:'60px'}}>
            <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'16px'}}>
              GET IN TOUCH
            </div>
            <h1 style={{fontSize:'clamp(32px, 5vw, 56px)', fontWeight:'900', color:'#0F172A', marginBottom:'12px', letterSpacing:'-2px'}}>
              Contact Us
            </h1>
            <p style={{color:'#64748B', fontSize:'17px', maxWidth:'500px', margin:'0 auto', lineHeight:'1.7'}}>
              Visit us at Kasturi Nagar, Bangalore or reach out online.
            </p>
          </div>

          <div style={{display:'grid', gridTemplateColumns:'1fr 1.5fr', gap:'32px', alignItems:'start'}}>

            <div style={{display:'flex', flexDirection:'column', gap:'16px'}}>
              {[
                { icon:'📍', title:'Our Location',  value:'Reg No 14/268A, 1st Floor, RS Arcade, 2nd Main Road, Kasturi Nagar, East of NGEF Layout, Bangalore - 560043' },
                { icon:'📞', title:'Phone Numbers', value:'+91 98456 55304\n+91 99804 77725\n080-35002588' },
                { icon:'📧', title:'Email Address', value:'maxface.in@gmail.com' },
                { icon:'🕐', title:'Working Hours', value:'Mon - Sat: 9:00 AM - 8:00 PM\nSunday: Emergency Only' },
              ].map((item) => (
                <div key={item.title} style={{background:'white', borderRadius:'16px', padding:'20px', display:'flex', gap:'14px', alignItems:'flex-start', border:'1px solid #F1F5F9', boxShadow:'0 2px 8px rgba(0,0,0,0.04)'}}>
                  <div style={{width:'44px', height:'44px', flexShrink:0, background:'#EFF6FF', borderRadius:'12px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'20px'}}>
                    {item.icon}
                  </div>
                  <div>
                    <h4 style={{fontWeight:'700', color:'#0F172A', marginBottom:'4px', fontSize:'14px'}}>{item.title}</h4>
                    <p style={{color:'#64748B', fontSize:'13px', lineHeight:'1.6', whiteSpace:'pre-line'}}>{item.value}</p>
                  </div>
                </div>
              ))}

              <div style={{borderRadius:'16px', overflow:'hidden', border:'1px solid #F1F5F9'}}>
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.5!2d77.6609!3d13.0037!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zS2FzdHVyaSBOYWdhciwgQmFuZ2Fsb3Jl!5e0!3m2!1sen!2sin!4v1234567890"
                  width="100%" height="200"
                  style={{border:0, display:'block'}}
                  allowFullScreen="" loading="lazy"
                />
              </div>

              <div style={{background:'white', borderRadius:'16px', padding:'20px', border:'1px solid #F1F5F9'}}>
                <h4 style={{fontWeight:'700', color:'#0F172A', marginBottom:'12px', fontSize:'14px'}}>Follow Us</h4>
                <div style={{display:'flex', gap:'10px'}}>
                  <a href="https://www.facebook.com/profile.php?id=100086378576580" target="_blank" rel="noreferrer" style={{display:'flex', alignItems:'center', gap:'8px', background:'#1877F2', color:'white', padding:'10px 18px', borderRadius:'10px', textDecoration:'none', fontSize:'13px', fontWeight:'600'}}>
                    <img src="https://cdn.simpleicons.org/facebook/white" width="18" height="18" alt="fb" />
                    Facebook
                  </a>
                  <a href="https://www.instagram.com/maxface.dental/" target="_blank" rel="noreferrer" style={{display:'flex', alignItems:'center', gap:'8px', background:'linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)', color:'white', padding:'10px 18px', borderRadius:'10px', textDecoration:'none', fontSize:'13px', fontWeight:'600'}}>
                    <img src="https://cdn.simpleicons.org/instagram/white" width="18" height="18" alt="ig" />
                    Instagram
                  </a>
                </div>
              </div>
            </div>

            <div style={{background:'white', borderRadius:'24px', padding:'40px', border:'1px solid #F1F5F9', boxShadow:'0 4px 24px rgba(0,0,0,0.06)'}}>
              {submitted ? (
                <div style={{textAlign:'center', padding:'40px 0'}}>
                  <div style={{fontSize:'64px', marginBottom:'20px'}}>✅</div>
                  <h3 style={{fontSize:'24px', fontWeight:'800', color:'#0F172A', marginBottom:'12px'}}>Message Sent!</h3>
                  <p style={{color:'#64748B', marginBottom:'24px', lineHeight:'1.7'}}>
                    Thank you! We will get back to you within 24 hours.
                  </p>
                  <button onClick={() => { setSubmitted(false); setForm({name:'', email:'', phone:'', message:''}) }} style={{background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)', color:'white', padding:'12px 28px', borderRadius:'10px', border:'none', fontWeight:'600', cursor:'pointer', fontSize:'14px'}}>
                    Send Another Message
                  </button>
                </div>
              ) : (
                <div>
                  <h3 style={{fontSize:'22px', fontWeight:'800', color:'#0F172A', marginBottom:'8px', letterSpacing:'-0.5px'}}>Send Us a Message</h3>
                  <p style={{color:'#64748B', fontSize:'14px', marginBottom:'28px'}}>Fill in the form below and our team will respond promptly.</p>

                  <div style={{display:'flex', flexDirection:'column', gap:'16px'}}>
                    <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px'}}>
                      <div>
                        <label style={{display:'block', fontSize:'13px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Full Name *</label>
                        <input name="name" value={form.name} onChange={handleChange} placeholder="Your name" style={{width:'100%', padding:'11px 14px', borderRadius:'10px', border:'1.5px solid #E2E8F0', fontSize:'14px', outline:'none', boxSizing:'border-box'}} />
                      </div>
                      <div>
                        <label style={{display:'block', fontSize:'13px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Phone</label>
                        <input name="phone" value={form.phone} onChange={handleChange} placeholder="+91 XXXXX XXXXX" style={{width:'100%', padding:'11px 14px', borderRadius:'10px', border:'1.5px solid #E2E8F0', fontSize:'14px', outline:'none', boxSizing:'border-box'}} />
                      </div>
                    </div>

                    <div>
                      <label style={{display:'block', fontSize:'13px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Email Address *</label>
                      <input name="email" value={form.email} onChange={handleChange} placeholder="your@email.com" style={{width:'100%', padding:'11px 14px', borderRadius:'10px', border:'1.5px solid #E2E8F0', fontSize:'14px', outline:'none', boxSizing:'border-box'}} />
                    </div>

                    <div>
                      <label style={{display:'block', fontSize:'13px', fontWeight:'600', color:'#374151', marginBottom:'8px'}}>Message *</label>
                      <textarea name="message" value={form.message} onChange={handleChange} placeholder="How can we help you?" rows={5} style={{width:'100%', padding:'11px 14px', borderRadius:'10px', border:'1.5px solid #E2E8F0', fontSize:'14px', outline:'none', resize:'vertical', boxSizing:'border-box'}} />
                    </div>

                    <button onClick={handleSubmit} disabled={loading} style={{width:'100%', padding:'14px', background: loading ? '#93C5FD' : 'linear-gradient(135deg, #1D4ED8, #0EA5E9)', color:'white', border:'none', borderRadius:'10px', fontSize:'15px', fontWeight:'700', cursor: loading ? 'not-allowed' : 'pointer'}}>
                      {loading ? 'Sending...' : 'Send Message'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}