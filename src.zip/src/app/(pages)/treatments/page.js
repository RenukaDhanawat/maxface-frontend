'use client'
import Link from 'next/link'

import Navbar from '@/components/common/Navbar'
import Footer from '@/components/common/Footer'

const treatments = [
  {
    image:'/gallery/blog-implants.jpg',
    slug:'dental-implants', title:'Dental Implants',
    desc:'Advanced implant solutions from basic to full mouth rehabilitation by certified implantologists.',
    time:'2-3 months', tag:'Speciality'
  },
  {
    image:'/gallery/Prosthodontics.webp',
    slug:'prosthodontics', title:'Prosthodontics',
    desc:'Complete dentures, crowns, bridges and advanced prosthetic solutions for missing teeth.',
    time:'2-4 weeks', tag:''
  },
  {
    image:'/gallery/endodontics.webp',
    slug:'endodontics', title:'Endodontics',
    desc:'Advanced root canal treatments using rotary endodontics for pain-free, single sitting procedures.',
    time:'1-2 sittings', tag:'Pain Free'
  },
  {
    image:'/gallery/periodontic.jpeg',
    slug:'periodontics', title:'Periodontics',
    desc:'Comprehensive gum disease treatment, scaling, flap surgery and laser periodontal therapy.',
    time:'2-3 visits', tag:''
  },
  {
    image:'',
    slug:'surgery', title:'Oral Surgery',
    desc:'Wisdom tooth removal, dental extractions and minor oral surgical procedures with precision.',
    time:'30-60 mins', tag:''
  },
  {
    image:'https://images.unsplash.com/photo-1543286386-713bdd548da4?w=400&h=250&fit=crop&auto=format',
    slug:'orthodontics', title:'Orthodontics',
    desc:'Metal braces, ceramic braces and invisible aligners for perfectly aligned teeth.',
    time:'6-18 months', tag:''
  },
  {
    image:'https://images.unsplash.com/photo-1598256989014-dce46f12c78e?w=400&h=250&fit=crop&auto=format',
    slug:'pedodontics', title:'Pedodontics',
    desc:'Specialized gentle dental care for children including preventive and restorative treatments.',
    time:'30-45 mins', tag:'Kids'
  },
  {
    image:'https://images.unsplash.com/photo-1571772996211-2912782087ca?w=400&h=250&fit=crop&auto=format',
    slug:'restorative-dentistry', title:'Restorative Dentistry',
    desc:'Tooth colored fillings, inlays, onlays and complete smile restoration procedures.',
    time:'1-2 visits', tag:''
  },
  {
    image:'https://images.unsplash.com/photo-1559757175-7cb036c8c9d3?w=400&h=250&fit=crop&auto=format',
    slug:'maxillofacial-prosthodontics', title:'Maxillofacial Prosthodontics',
    desc:'Specialized anaplastology and facial prosthetics — a unique expertise at Maxface Clinic.',
    time:'Custom', tag:'Unique'
  },
]

export default function TreatmentsPage() {
  return (
    <div>
      <Navbar />

      {/* Hero with background */}
      <section style={{
        paddingTop:'140px', paddingBottom:'80px',
        paddingLeft:'24px', paddingRight:'24px',
        textAlign:'center', position:'relative',
        overflow:'hidden', minHeight:'360px',
        display:'flex', alignItems:'center', justifyContent:'center'
      }}>
        <div style={{
          position:'absolute', top:0, left:0, right:0, bottom:0,
          backgroundImage:'url(https://images.unsplash.com/photo-1588776814546-1ffedbe47425?w=1400&h=500&fit=crop&auto=format)',
          backgroundSize:'cover', backgroundPosition:'center',
          filter:'brightness(0.2)'
        }}/>
        <div style={{
          position:'absolute', top:0, left:0, right:0, bottom:0,
          background:'linear-gradient(to bottom, rgba(15,23,42,0.4), rgba(15,23,42,0.75))'
        }}/>
        <div style={{position:'relative', zIndex:1}}>
          <div style={{
            display:'inline-block', background:'rgba(255,255,255,0.15)',
            color:'white', padding:'6px 16px', borderRadius:'20px',
            fontSize:'13px', fontWeight:'600', marginBottom:'16px',
            letterSpacing:'0.5px', border:'1px solid rgba(255,255,255,0.2)'
          }}>
            OUR TREATMENTS
          </div>
          <h1 style={{fontSize:'clamp(28px, 4vw, 56px)', fontWeight:'900', color:'white', marginBottom:'16px', letterSpacing:'-1px'}}>
            Comprehensive Dental Care
          </h1>
          <p style={{fontSize:'18px', color:'rgba(255,255,255,0.85)', maxWidth:'600px', margin:'0 auto', lineHeight:'1.7'}}>
            From routine checkups to advanced implant surgeries — all dental treatments under one roof in Bangalore.
          </p>
        </div>
      </section>

      {/* Treatments Grid */}
      <section style={{padding:'80px 24px', background:'#F8FAFC'}}>
        <div style={{maxWidth:'1280px', margin:'0 auto', display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(320px, 1fr))', gap:'24px'}}>
          {treatments.map((t) => (
            <div key={t.slug} style={{
              background:'white', borderRadius:'20px', overflow:'hidden',
              border:'1px solid #F1F5F9', transition:'all 0.3s ease',
              boxShadow:'0 2px 8px rgba(0,0,0,0.04)'
            }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = '#DBEAFE'
                e.currentTarget.style.transform = 'translateY(-6px)'
                e.currentTarget.style.boxShadow = '0 20px 40px rgba(29,78,216,0.1)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = '#F1F5F9'
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.04)'
              }}
            >
              {/* Image */}
              <div style={{position:'relative', height:'200px', overflow:'hidden'}}>
                <img
                  src={t.image}
                  alt={t.title}
                  style={{width:'100%', height:'100%', objectFit:'cover', transition:'transform 0.3s'}}
                  onMouseEnter={e => e.target.style.transform = 'scale(1.05)'}
                  onMouseLeave={e => e.target.style.transform = 'scale(1)'}
                />
                <div style={{
                  position:'absolute', bottom:0, left:0, right:0,
                  height:'80px',
                  background:'linear-gradient(to top, rgba(0,0,0,0.4), transparent)'
                }}/>
                {t.tag && (
                  <div style={{
                    position:'absolute', top:'12px', right:'12px',
                    background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
                    color:'white', padding:'4px 12px', borderRadius:'20px',
                    fontSize:'11px', fontWeight:'700'
                  }}>
                    {t.tag}
                  </div>
                )}
              </div>

              {/* Content */}
              <div style={{padding:'24px'}}>
                <h3 style={{fontSize:'18px', fontWeight:'700', color:'#0F172A', marginBottom:'10px'}}>
                  {t.title}
                </h3>
                <p style={{fontSize:'14px', color:'#64748B', lineHeight:'1.6', marginBottom:'16px'}}>
                  {t.desc}
                </p>

                {/* Duration */}
                <div style={{
                  display:'inline-flex', alignItems:'center', gap:'6px',
                  background:'#F8FAFC', padding:'6px 12px', borderRadius:'8px',
                  fontSize:'12px', color:'#64748B', marginBottom:'20px',
                  border:'1px solid #F1F5F9'
                }}>
                  ⏱ {t.time}
                </div>

                {/* CTA */}
                <div style={{display:'flex', gap:'10px'}}>
                  <Link href={`/treatments/${t.slug}`} style={{
                    flex:1, textAlign:'center', padding:'10px',
                    background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
                    color:'white', borderRadius:'10px', textDecoration:'none',
                    fontSize:'13px', fontWeight:'600',
                    boxShadow:'0 4px 12px rgba(29,78,216,0.2)'
                  }}>
                    Learn More
                  </Link>
                  <Link href="/appointment" style={{
                    flex:1, textAlign:'center', padding:'10px',
                    background:'white', color:'#1D4ED8', borderRadius:'10px',
                    textDecoration:'none', fontSize:'13px', fontWeight:'600',
                    border:'1px solid #DBEAFE'
                  }}>
                    Book Now
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  )
}