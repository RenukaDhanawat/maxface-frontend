'use client'
import { useState } from 'react'
import Navbar from '@/components/common/Navbar'
import Footer from '@/components/common/Footer'

const categories = ['All', 'Implants', 'Whitening', 'Braces', 'Smile Makeover']

const galleryItems = [
  { id:1, category:'Implants',       image:'/gallery/implant.webp',    label:'Dental Implant',    desc:'Natural looking permanent tooth' },
  { id:2, category:'Whitening',      image:'/gallery/whitening.avif',  label:'Teeth Whitening',   desc:'8 shades whiter in 1 session' },
  { id:3, category:'Braces',         image:'/gallery/braces.jpg',     label:'Braces Treatment',  desc:'12 months transformation' },
  { id:4, category:'Smile Makeover', image:'/gallery/smile.webp',      label:'Smile Makeover',    desc:'Complete smile transformation' },
  { id:5, category:'Implants',       image:'/gallery/implant2.webp',   label:'Full Mouth Implants', desc:'Complete restoration' },
  { id:6, category:'Whitening',      image:'/gallery/whitening2.jpg', label:'Deep Whitening',    desc:'Professional bleaching result' },
  { id:7, category:'Braces',         image:'/gallery/aligners.png',   label:'Invisible Aligners', desc:'Clear aligner treatment' },
  { id:8, category:'Smile Makeover', image:'/gallery/veneers.webp',    label:'Veneers',            desc:'Porcelain veneer makeover' },
]

export default function GalleryPage() {
  const [activeCategory, setActiveCategory] = useState('All')

  const filtered = activeCategory === 'All'
    ? galleryItems
    : galleryItems.filter(item => item.category === activeCategory)

  return (
    <>
      <Navbar />

      {/* Hero */}
      <section style={{
        paddingTop:'140px', paddingBottom:'80px', paddingLeft:'24px', paddingRight:'24px',
        background:'linear-gradient(135deg, #EFF6FF, #F0FDFA)', textAlign:'center'
      }}>
        <div style={{display:'inline-block', background:'#DBEAFE', color:'#3B9EFF', padding:'6px 16px', borderRadius:'20px', fontSize:'14px', fontWeight:'500', marginBottom:'16px'}}>
          Smile Gallery
        </div>
        <h1 style={{fontSize:'clamp(28px, 4vw, 56px)', fontWeight:'800', color:'#1A1A2E', marginBottom:'16px'}}>
          Before & After Results
        </h1>
        <p style={{fontSize:'18px', color:'#6B7280', maxWidth:'600px', margin:'0 auto'}}>
          Real patients, real results. See the amazing transformations our patients have experienced.
        </p>
      </section>

      {/* Gallery */}
      <section style={{padding:'80px 24px', background:'white'}}>
        <div style={{maxWidth:'1200px', margin:'0 auto'}}>

          {/* Filter Buttons */}
          <div style={{display:'flex', gap:'12px', justifyContent:'center', flexWrap:'wrap', marginBottom:'48px'}}>
            {categories.map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)} style={{
                padding:'10px 24px', borderRadius:'50px', border:'2px solid',
                borderColor: activeCategory === cat ? '#3B9EFF' : '#E5E7EB',
                background: activeCategory === cat ? '#3B9EFF' : 'white',
                color: activeCategory === cat ? 'white' : '#6B7280',
                fontWeight:'600', fontSize:'14px', cursor:'pointer',
                transition:'all 0.2s'
              }}>
                {cat}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(280px, 1fr))', gap:'24px'}}>
            {filtered.map(item => (
              <div key={item.id} style={{
                background:'#F8FAFF', borderRadius:'20px', overflow:'hidden',
                boxShadow:'0 4px 20px rgba(0,0,0,0.06)', transition:'transform 0.3s'
              }}
                onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-6px)'}
                onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
              >
{/* Single Image */}
<div style={{position:'relative', height:'200px', overflow:'hidden'}}>
  <img
    src={item.image}
    alt={item.label}
    style={{width:'100%', height:'100%', objectFit:'cover', transition:'transform 0.3s ease'}}
    onMouseEnter={e => e.target.style.transform = 'scale(1.05)'}
    onMouseLeave={e => e.target.style.transform = 'scale(1)'}
    onError={e => {
      e.target.style.display = 'none'
      e.target.parentNode.style.background = '#EFF6FF'
      e.target.parentNode.style.display = 'flex'
      e.target.parentNode.style.alignItems = 'center'
      e.target.parentNode.style.justifyContent = 'center'
    }}
  />
  <span style={{
    position:'absolute', top:'12px', right:'12px',
    background:'rgba(29,78,216,0.85)', color:'white',
    padding:'4px 12px', borderRadius:'20px',
    fontSize:'11px', fontWeight:'700'
  }}>
    {item.category}
  </span>
</div>
                {/* Info */}
                <div style={{padding:'20px'}}>
                  <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'8px'}}>
                    <h3 style={{fontSize:'16px', fontWeight:'700', color:'#1A1A2E'}}>{item.label}</h3>
                    <span style={{
                      background:'#DBEAFE', color:'#3B9EFF',
                      padding:'4px 10px', borderRadius:'20px', fontSize:'11px', fontWeight:'600'
                    }}>
                      {item.category}
                    </span>
                  </div>
                  <p style={{fontSize:'13px', color:'#6B7280'}}>{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div style={{textAlign:'center', marginTop:'60px'}}>
            <p style={{color:'#6B7280', fontSize:'16px', marginBottom:'20px'}}>
              Want to see your own transformation?
            </p>
            <a href="/appointment" style={{
              display:'inline-block',
              background:'linear-gradient(135deg, #3B9EFF, #2563EB)',
              color:'white', padding:'16px 40px', borderRadius:'50px',
              textDecoration:'none', fontWeight:'700', fontSize:'16px'
            }}>
              📅 Book Your Consultation
            </a>
          </div>

        </div>
      </section>

      <Footer />
    </>
  )
}