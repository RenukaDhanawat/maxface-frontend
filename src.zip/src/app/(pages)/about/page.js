import Navbar from '@/components/common/Navbar'
import Footer from '@/components/common/Footer'
import Link from 'next/link'

export default function AboutPage() {
  return (
    <>
      <Navbar />

      {/* Hero */}
      <section style={{
        paddingTop:'140px', paddingBottom:'80px', paddingLeft:'24px', paddingRight:'24px',
        background:'linear-gradient(160deg, #F8FAFF 0%, #EFF6FF 60%, #F0F9FF 100%)', textAlign:'center'
      }}>
        <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'16px', letterSpacing:'0.5px'}}>
          ABOUT US
        </div>
        <h1 style={{fontSize:'clamp(32px, 5vw, 60px)', fontWeight:'900', color:'#0F172A', marginBottom:'16px', letterSpacing:'-2px'}}>
          Our Story
        </h1>
        <p style={{fontSize:'18px', color:'#64748B', maxWidth:'600px', margin:'0 auto', lineHeight:'1.7'}}>
          A personalized approach to create the perfect smile — Maxface Dental Implant and Anaplastology Clinic, Bangalore.
        </p>
      </section>

      {/* Clinic Story */}
      <section style={{padding:'80px 24px', background:'white'}}>
        <div style={{maxWidth:'1280px', margin:'0 auto', display:'grid', gridTemplateColumns:'1fr 1fr', gap:'80px', alignItems:'center'}}>
          <div>
            <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'20px'}}>
              OUR HISTORY
            </div>
            <h2 style={{fontSize:'clamp(24px, 3vw, 40px)', fontWeight:'800', color:'#0F172A', marginBottom:'20px', letterSpacing:'-1px'}}>
              Trusted Since 2016
            </h2>
            <p style={{fontSize:'16px', color:'#64748B', lineHeight:'1.8', marginBottom:'16px'}}>
              Maxface Dental Implant and Anaplastology Clinic was founded with a simple yet powerful vision — to provide world-class dental care with a personal touch in Bangalore.
            </p>
            <p style={{fontSize:'16px', color:'#64748B', lineHeight:'1.8', marginBottom:'16px'}}>
              Located in Kasturi Nagar, East Bangalore, we have grown into one of the most trusted dental implant and anaplastology centers in the region.
            </p>
            <p style={{fontSize:'16px', color:'#64748B', lineHeight:'1.8'}}>
              We love to see you smile always. Our team of professionals work passionately to provide individualized care and quality service to each patient.
            </p>
          </div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px'}}>
            {[
              { number:'5000+', label:'Happy Patients' },
              { number:'8+',    label:'Years Experience' },
              { number:'15+',   label:'Treatments' },
              { number:'4.9',   label:'Google Rating' },
            ].map((stat) => (
              <div key={stat.label} style={{
                background:'linear-gradient(135deg, #F8FAFF, #EFF6FF)',
                borderRadius:'20px', padding:'28px', textAlign:'center',
                border:'1px solid #DBEAFE'
              }}>
                <div style={{fontSize:'32px', fontWeight:'900', color:'#1D4ED8', marginBottom:'8px', letterSpacing:'-1px'}}>
                  {stat.number}
                </div>
                <div style={{fontSize:'13px', color:'#64748B', fontWeight:'500'}}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section style={{padding:'80px 24px', background:'#F8FAFC'}}>
        <div style={{maxWidth:'1280px', margin:'0 auto'}}>
          <div style={{textAlign:'center', marginBottom:'48px'}}>
            <h2 style={{fontSize:'clamp(24px, 3vw, 40px)', fontWeight:'800', color:'#0F172A', letterSpacing:'-1px'}}>
              Our Vision and Mission
            </h2>
          </div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'24px'}}>
            <div style={{background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)', borderRadius:'24px', padding:'40px', color:'white'}}>
              <div style={{fontSize:'48px', marginBottom:'20px'}}>🎯</div>
              <h3 style={{fontSize:'22px', fontWeight:'700', marginBottom:'16px'}}>Our Vision</h3>
              <p style={{fontSize:'15px', lineHeight:'1.8', opacity:0.9}}>
                To be Bangalore's most trusted dental implant clinic, where every patient leaves with a confident smile. We envision a world where quality dental care is accessible and personalized for everyone.
              </p>
            </div>
            <div style={{background:'linear-gradient(135deg, #0F172A, #1E3A5F)', borderRadius:'24px', padding:'40px', color:'white'}}>
              <div style={{fontSize:'48px', marginBottom:'20px'}}>🚀</div>
              <h3 style={{fontSize:'22px', fontWeight:'700', marginBottom:'16px'}}>Our Mission</h3>
              <p style={{fontSize:'15px', lineHeight:'1.8', opacity:0.9}}>
                To deliver exceptional dental care through advanced implantology, anaplastology, and a patient-first approach. We are committed to making every visit comfortable, effective and transformative.
              </p>
            </div>
          </div>
        </div>
      </section>

{/* Doctor */}
<section style={{padding:'80px 24px', background:'white'}}>
  <div style={{maxWidth:'1280px', margin:'0 auto', display:'grid', gridTemplateColumns:'1fr 1.5fr', gap:'80px', alignItems:'center'}}>

    <div style={{display:'flex', justifyContent:'center'}}>
      <div style={{
        width:'320px',
        height:'380px',
        borderRadius:'32px',
        overflow:'hidden',
        boxShadow:'0 40px 80px rgba(29,78,216,0.2)'
      }}>
        <img
          src="doctorphoto.jpg"
          alt="Dr Srinivasa Rao"
          style={{
            width:'100%',
            height:'100%',
            objectFit:'cover'
          }}
        />
      </div>
    </div>

    <div>
      <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'20px'}}>
        LEAD SPECIALIST
      </div>

      <h2 style={{fontSize:'clamp(24px, 3vw, 40px)', fontWeight:'800', color:'#0F172A', marginBottom:'8px', letterSpacing:'-1px'}}>
        Dr. Srinivasa Rao
      </h2>

      <p style={{color:'#1D4ED8', fontWeight:'600', marginBottom:'20px', fontSize:'16px'}}>
        Oral and Maxillofacial Surgeon — Implantologist
      </p>

      <p style={{color:'#64748B', lineHeight:'1.8', marginBottom:'24px', fontSize:'15px'}}>
        Dr. Srinivasa Rao is one of Bangalore's most trusted dental implant specialists with expertise in oral surgery, implantology, and anaplastology.
      </p>

      <Link href="/appointment" style={{
        display:'inline-block',
        background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
        color:'white',
        padding:'14px 32px',
        borderRadius:'10px',
        textDecoration:'none',
        fontWeight:'700',
        fontSize:'15px'
      }}>
        Book Consultation
      </Link>

    </div>

  </div>
</section>
      {/* Academy */}
      <section style={{padding:'60px 24px', background:'linear-gradient(135deg, #0F172A, #1E3A5F)'}}>
        <div style={{maxWidth:'1280px', margin:'0 auto', display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:'24px'}}>
          <div>
            <div style={{display:'inline-block', background:'rgba(255,255,255,0.1)', color:'#93C5FD', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'16px'}}>
              IMPLANTOLOGY TRAINING
            </div>
            <h3 style={{fontSize:'28px', fontWeight:'800', color:'white', marginBottom:'8px', letterSpacing:'-0.5px'}}>
              Maxface Implantology Academy
            </h3>
            <p style={{color:'#94A3B8', fontSize:'15px', maxWidth:'500px'}}>
              Basic to Advanced Comprehensive Implantology Course for dental professionals.
            </p>
          </div>
          
            <a href="http://maxface.in/wp-content/uploads/2023/05/Maxface-Academy-Final-Brochure_compressed.pdf"
            target="_blank" rel="noreferrer"
            style={{
              background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
              color:'white', padding:'14px 32px', borderRadius:'10px',
              textDecoration:'none', fontWeight:'700', fontSize:'15px',
              boxShadow:'0 4px 12px rgba(29,78,216,0.4)', whiteSpace:'nowrap'
            }}
          >
            Download Brochure
          </a>
        </div>
      </section>

      {/* CTA */}
      <section style={{padding:'80px 24px', textAlign:'center', background:'white'}}>
        <h2 style={{fontSize:'clamp(24px, 3vw, 40px)', fontWeight:'800', color:'#0F172A', marginBottom:'16px', letterSpacing:'-1px'}}>
          Ready to Meet Us?
        </h2>
        <p style={{color:'#64748B', fontSize:'18px', marginBottom:'36px'}}>
          Visit us at Kasturi Nagar, Bangalore or book online today.
        </p>
        <Link href="/appointment" style={{
          background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
          color:'white', padding:'15px 40px', borderRadius:'12px',
          textDecoration:'none', fontWeight:'700', fontSize:'15px',
          boxShadow:'0 8px 24px rgba(29,78,216,0.3)'
        }}>
          Book Appointment
        </Link>
      </section>

      <Footer />
    </>
  )
}