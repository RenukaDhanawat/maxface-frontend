'use client'

export default function WhyChooseUs() {
  const reasons = [
    { icon:'🏆', title:'Since 2016',               desc:'Over 8 years of delivering exceptional dental care to thousands of patients in Bangalore.' },
    { icon:'🔬', title:'Advanced Technology',       desc:'State-of-the-art dental equipment for precise, comfortable and effective treatments.' },
    { icon:'💉', title:'Pain-Free Treatment',       desc:'Advanced anaesthesia and gentle techniques ensure a completely comfortable experience.' },
    { icon:'👨‍⚕️', title:'Expert Specialists',     desc:'Our team of certified oral surgeons and implantologists with international training.' },
    { icon:'🦷', title:'Implant Specialists',       desc:'Basic to advanced implantology — we are one of Bangalore\'s most trusted implant clinics.' },
    { icon:'🎓', title:'Implantology Academy',      desc:'We also run an implantology training course for dental professionals. Download our brochure.' },
  ]

  return (
    <section style={{padding:'80px 24px', background:'#F8FAFC'}}>
      <div style={{maxWidth:'1280px', margin:'0 auto'}}>
        <div style={{textAlign:'center', marginBottom:'60px'}}>
          <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'16px', letterSpacing:'0.5px'}}>
            WHY CHOOSE US
          </div>
          <h2 style={{fontSize:'clamp(28px, 4vw, 44px)', fontWeight:'800', color:'#0F172A', marginBottom:'16px', letterSpacing:'-1px'}}>
            Why Patients Trust Maxface
          </h2>
          <p style={{fontSize:'16px', color:'#64748B', maxWidth:'500px', margin:'0 auto', lineHeight:'1.7'}}>
            Combining expertise, technology and compassion to deliver Bangalore's best dental experience.
          </p>
        </div>

        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(300px, 1fr))', gap:'20px'}}>
          {reasons.map((reason) => (
            <div key={reason.title} style={{
              display:'flex', gap:'16px', alignItems:'flex-start',
              background:'white', borderRadius:'16px', padding:'24px',
              border:'1px solid #F1F5F9',
              boxShadow:'0 2px 8px rgba(0,0,0,0.04)',
              transition:'all 0.2s'
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = '#DBEAFE'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(29,78,216,0.08)' }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#F1F5F9'; e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.04)' }}
            >
              <div style={{
                width:'52px', height:'52px', flexShrink:0,
                background:'#EFF6FF', borderRadius:'14px',
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize:'26px'
              }}>
                {reason.icon}
              </div>
              <div>
                <h3 style={{fontSize:'16px', fontWeight:'700', color:'#0F172A', marginBottom:'6px'}}>
                  {reason.title}
                </h3>
                <p style={{fontSize:'14px', color:'#64748B', lineHeight:'1.6'}}>
                  {reason.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}