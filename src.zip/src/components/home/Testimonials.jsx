'use client'
import { useState } from 'react'

const testimonials = [
  {
    name: 'Chandrakala Jayanthi',
    treatment: 'Dental Implants',
    rating: 5,
    review: 'I got my smile back! From the very first consultation, Dr. Srinivas explained every step with patience and clarity, making me feel completely comfortable. His expertise and attention to detail truly stand out. The results are excellent — my smile feels natural and comfortable again.',
    avatar: '👩',
    time: '4 months ago'
  },
  {
    name: 'Ganga Jayaraman',
    treatment: 'Teeth Cleaning & Filling',
    rating: 5,
    review: 'I had a wonderful experience at Max Face Dental and Implant Clinic with Dr. Srinivas. The entire process was smooth and completely painless. Dr. Srinivas is very gentle, patient, and explains every step clearly. The clinic is clean, well-equipped, and has a calm atmosphere.',
    avatar: '👩‍🦱',
    time: '4 months ago'
  },
  {
    name: 'HARLEEN',
    treatment: 'Smile Design & Implants',
    rating: 5,
    review: 'As a dentist myself, I\'m naturally cautious about trusting another professional — but with Dr. Shrinivas, the choice was simple. His expertise is unmatched and his reputation as India\'s representative at international events speaks for itself. All my requirements were met and how!',
    avatar: '👩‍⚕️',
    time: '1 year ago'
  },
  {
    name: 'Amarnadh Chavallam',
    treatment: 'Dental Treatment',
    rating: 5,
    review: 'I recently visited Dr. Srinivas for dental treatment, and I couldn\'t be happier. The care I received was outstanding. What truly stood out was the level of personal attention I received. The follow-up care was exceptional, making me feel valued as a patient.',
    avatar: '👨',
    time: '1 year ago'
  },
  {
    name: 'Kiran',
    treatment: 'Smile Design & Implants',
    rating: 5,
    review: 'After a small accident, I had lost confidence in my smile. Thanks to the amazing smile design and implant treatment, I got my beautiful smile back! The entire process was smooth, comfortable, and personalized to my needs. The results look completely natural.',
    avatar: '🧑',
    time: '1 month ago'
  },
  {
    name: 'venkata karthik',
    treatment: 'Dental Implants',
    rating: 5,
    review: 'Dr. Sreenivas sir is one of the finest and most responsible implantologists in Bangalore. He really took his time to explain my condition. I had a great visit and the doctor\'s demeanor really put me at ease. I highly recommend this clinic.',
    avatar: '👨‍💼',
    time: '2 years ago'
  },
]

export default function Testimonials() {
  const [current, setCurrent] = useState(0)
  const t = testimonials[current]

  return (
    <section style={{padding:'80px 24px', background:'#F8FAFC'}}>
      <div style={{maxWidth:'900px', margin:'0 auto', textAlign:'center'}}>

        {/* Header */}
        <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'16px', letterSpacing:'0.5px'}}>
          PATIENT REVIEWS
        </div>
        <h2 style={{fontSize:'clamp(28px, 4vw, 44px)', fontWeight:'800', color:'#0F172A', marginBottom:'12px', letterSpacing:'-1px'}}>
          Changing Lives One Smile at a Time
        </h2>
        <p style={{color:'#64748B', fontSize:'16px', marginBottom:'48px'}}>
          Real reviews from our patients on Google
        </p>

        {/* Card */}
        <div style={{
          background:'white', borderRadius:'24px', padding:'48px',
          boxShadow:'0 4px 24px rgba(0,0,0,0.06)',
          border:'1px solid #F1F5F9', marginBottom:'32px', position:'relative'
        }}>
          {/* Google badge */}
          <div style={{
            position:'absolute', top:'20px', right:'20px',
            display:'flex', alignItems:'center', gap:'6px',
            background:'#F8FAFC', padding:'6px 12px', borderRadius:'20px',
            border:'1px solid #F1F5F9'
          }}>
            <img src="https://cdn.simpleicons.org/google/EA4335" width="14" height="14" alt="Google" />
            <span style={{fontSize:'12px', color:'#64748B', fontWeight:'600'}}>Google Review</span>
          </div>

          {/* Quote mark */}
          <div style={{fontSize:'80px', lineHeight:'1', color:'#EFF6FF', position:'absolute', top:'16px', left:'28px', fontFamily:'Georgia', fontWeight:'900', userSelect:'none'}}>
            "
          </div>

          {/* Stars */}
          <div style={{display:'flex', justifyContent:'center', gap:'4px', marginBottom:'20px'}}>
            {[...Array(t.rating)].map((_, i) => (
              <span key={i} style={{color:'#FBBF24', fontSize:'22px'}}>★</span>
            ))}
          </div>

          {/* Review */}
          <p style={{fontSize:'17px', color:'#374151', lineHeight:'1.8', marginBottom:'32px', fontStyle:'italic', position:'relative', zIndex:1, maxWidth:'680px', margin:'0 auto 32px'}}>
            "{t.review}"
          </p>

          {/* Patient */}
          <div style={{display:'flex', alignItems:'center', justifyContent:'center', gap:'14px'}}>
            <div style={{
              width:'52px', height:'52px', borderRadius:'50%',
              background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
              display:'flex', alignItems:'center', justifyContent:'center', fontSize:'26px'
            }}>
              {t.avatar}
            </div>
            <div style={{textAlign:'left'}}>
              <div style={{fontWeight:'700', color:'#0F172A', fontSize:'16px'}}>{t.name}</div>
              <div style={{color:'#1D4ED8', fontSize:'13px', fontWeight:'500'}}>{t.treatment}</div>
              <div style={{color:'#94A3B8', fontSize:'12px'}}>{t.time}</div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div style={{display:'flex', alignItems:'center', justifyContent:'center', gap:'16px'}}>
          <button
            onClick={() => setCurrent(c => c === 0 ? testimonials.length - 1 : c - 1)}
            style={{width:'44px', height:'44px', borderRadius:'50%', border:'1.5px solid #DBEAFE', background:'white', color:'#1D4ED8', fontSize:'18px', cursor:'pointer'}}
          >←</button>

          <div style={{display:'flex', gap:'8px'}}>
            {testimonials.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)} style={{
                width: i === current ? '28px' : '8px', height:'8px',
                borderRadius:'4px', border:'none', cursor:'pointer',
                background: i === current ? '#1D4ED8' : '#CBD5E1',
                transition:'all 0.3s ease'
              }}/>
            ))}
          </div>

          <button
            onClick={() => setCurrent(c => c === testimonials.length - 1 ? 0 : c + 1)}
            style={{width:'44px', height:'44px', borderRadius:'50%', border:'1.5px solid #DBEAFE', background:'white', color:'#1D4ED8', fontSize:'18px', cursor:'pointer'}}
          >→</button>
        </div>

        {/* Google Rating */}
        <div style={{marginTop:'32px', display:'flex', alignItems:'center', justifyContent:'center', gap:'8px'}}>
          <img src="https://cdn.simpleicons.org/google/EA4335" width="18" height="18" alt="Google" />
          <span style={{fontWeight:'700', color:'#0F172A', fontSize:'15px'}}>4.9</span>
          <div style={{display:'flex', gap:'2px'}}>
            {[...Array(5)].map((_, i) => (
              <span key={i} style={{color:'#FBBF24', fontSize:'16px'}}>★</span>
            ))}
          </div>
          <span style={{color:'#64748B', fontSize:'14px'}}>on Google</span>
        </div>

      </div>
    </section>
  )
}