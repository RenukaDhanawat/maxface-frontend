import Link from 'next/link'

export default function EmergencySection() {
  return (
    <>
      {/* Emergency */}
      <section style={{padding:'32px 24px', background:'white', borderTop:'1px solid #FEE2E2', borderBottom:'1px solid #FEE2E2'}}>
        <div style={{maxWidth:'1280px', margin:'0 auto', display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:'20px'}}>
          <div style={{display:'flex', alignItems:'center', gap:'16px'}}>
            <div style={{width:'52px', height:'52px', background:'#FEE2E2', borderRadius:'14px', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'24px'}}>
              🚨
            </div>
            <div>
              <h3 style={{fontSize:'18px', fontWeight:'700', color:'#0F172A', marginBottom:'2px'}}>Dental Emergency?</h3>
              <p style={{fontSize:'14px', color:'#EF4444'}}>Call us immediately for urgent dental care</p>
            </div>
          </div>
          <a href="tel:+919980477725" style={{
            background:'#EF4444', color:'white', padding:'12px 28px',
            borderRadius:'10px', textDecoration:'none', fontWeight:'700',
            fontSize:'15px', display:'flex', alignItems:'center', gap:'8px',
            boxShadow:'0 4px 12px rgba(239,68,68,0.3)'
          }}>
            📞 +91 99804 77725
          </a>
        </div>
      </section>

      {/* CTA */}
      <section style={{
        padding:'80px 24px', textAlign:'center',
        background:'linear-gradient(135deg, #0F172A 0%, #1E3A5F 50%, #0F172A 100%)'
      }}>
        <div style={{maxWidth:'700px', margin:'0 auto'}}>
          <div style={{fontSize:'48px', marginBottom:'20px'}}>🦷</div>
          <h2 style={{fontSize:'clamp(28px, 4vw, 44px)', fontWeight:'800', color:'white', marginBottom:'16px', letterSpacing:'-1px'}}>
            Ready for Your Perfect Smile?
          </h2>
          <p style={{fontSize:'18px', color:'#94A3B8', marginBottom:'40px', lineHeight:'1.7'}}>
            Visit us at Kasturi Nagar, Bangalore or call to book your appointment today.
          </p>
          <div style={{display:'flex', gap:'16px', justifyContent:'center', flexWrap:'wrap'}}>
            <Link href="/appointment" style={{
              background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
              color:'white', padding:'15px 36px', borderRadius:'12px',
              textDecoration:'none', fontWeight:'700', fontSize:'15px',
              boxShadow:'0 8px 24px rgba(29,78,216,0.4)'
            }}>
              Book Appointment
            </Link>
            <a href="tel:+919845655304" style={{
              background:'transparent', color:'white', padding:'15px 36px',
              borderRadius:'12px', textDecoration:'none', fontWeight:'600',
              fontSize:'15px', border:'1px solid rgba(255,255,255,0.2)'
            }}>
              📞 +91 98456 55304
            </a>
          </div>
        </div>
      </section>
    </>
  )
}