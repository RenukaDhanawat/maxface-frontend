'use client'
import Link from 'next/link'
import Image from 'next/image'
import { useEffect, useState } from 'react'

export default function HeroSection() {

  const [count, setCount] = useState({
    patients: 0,
    years: 0,
    treatments: 0
  })

  useEffect(() => {
    const timer = setTimeout(() => {
      setCount({
        patients: 5000,
        years: 8,
        treatments: 15
      })
    }, 600)

    return () => clearTimeout(timer)
  }, [])

  return (

    <section style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      paddingTop: '80px',
      background:
        'linear-gradient(160deg,#F8FAFF 0%,#EFF6FF 40%,#F0F9FF 100%)',
      position: 'relative',
      overflow: 'hidden'
    }}>

      {/* Glow Background */}
      <div style={{
        position: 'absolute',
        width: '600px',
        height: '600px',
        borderRadius: '50%',
        background: 'radial-gradient(circle,#60A5FA33,transparent 70%)',
        top: '-200px',
        right: '-200px'
      }}/>

      <div style={{
        position: 'absolute',
        width: '500px',
        height: '500px',
        borderRadius: '50%',
        background: 'radial-gradient(circle,#38BDF833,transparent 70%)',
        bottom: '-200px',
        left: '-200px'
      }}/>

      <div style={{
        maxWidth: '1280px',
        margin: '0 auto',
        padding: '60px 24px',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '80px',
        alignItems: 'center'
      }}>

        {/* LEFT SIDE */}

        <div>

          {/* Badge */}

          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            padding: '6px 14px',
            borderRadius: '50px',
            border: '1px solid #DBEAFE',
            background: 'white',
            marginBottom: '28px',
            boxShadow: '0 4px 12px rgba(29,78,216,0.08)'
          }}>
            <div style={{
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              background: '#22C55E'
            }}/>
            <span style={{
              fontSize: '13px',
              color: '#2563EB',
              fontWeight: '600'
            }}>
              Trusted Dental Clinic in Bangalore
            </span>
          </div>

          {/* Heading */}

          <h1 style={{
            fontSize: 'clamp(42px,5vw,70px)',
            fontWeight: '900',
            lineHeight: '1.05',
            letterSpacing: '-2px',
            marginBottom: '24px',
            color: '#0F172A'
          }}>
            Designing
            <br/>

            <span style={{
              background:
                'linear-gradient(135deg,#2563EB,#06B6D4)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Beautiful Smiles
            </span>

            <br/>

            That Last Forever
          </h1>

          {/* Description */}

          <p style={{
            fontSize: '18px',
            color: '#64748B',
            lineHeight: '1.7',
            marginBottom: '36px',
            maxWidth: '480px'
          }}>
            Maxface Dental Implant & Anaplastology Clinic in Bangalore —
            delivering world-class dental treatments with
            advanced technology and personalized care.
          </p>

          {/* CTA Buttons */}

          <div style={{
            display: 'flex',
            gap: '14px',
            flexWrap: 'wrap',
            marginBottom: '48px'
          }}>

            <Link
              href="/appointment"
              style={{
                background:
                  'linear-gradient(135deg,#2563EB,#06B6D4)',
                color: 'white',
                padding: '16px 34px',
                borderRadius: '12px',
                fontWeight: '700',
                textDecoration: 'none',
                boxShadow:
                  '0 12px 30px rgba(37,99,235,0.35)',
                transition: 'all .25s'
              }}
            >
              Book Appointment →
            </Link>

            <a
              href="tel:+919980477725"
              style={{
                background: 'white',
                border: '1px solid #E2E8F0',
                padding: '16px 30px',
                borderRadius: '12px',
                textDecoration: 'none',
                fontWeight: '600',
                color: '#0F172A'
              }}
            >
              📞 Call Now
            </a>

          </div>

          {/* Stats */}

          <div style={{
            display: 'flex',
            gap: '40px',
            paddingTop: '32px',
            borderTop: '1px solid #E2E8F0'
          }}>

            <Stat value={`${count.patients}+`} label="Happy Patients"/>
            <Stat value={`${count.years}+`} label="Years Experience"/>
            <Stat value={`${count.treatments}+`} label="Dental Treatments"/>

          </div>

        </div>

        {/* RIGHT SIDE */}

        <div style={{
          position: 'relative',
          display: 'flex',
          justifyContent: 'center'
        }}>

          {/* Doctor Image */}

          <div style={{
            width: '420px',
            height: '500px',
            borderRadius: '28px',
            overflow: 'hidden',
            boxShadow:
              '0 40px 80px rgba(37,99,235,0.25)'
          }}>

            <Image
              src="/doctor.png"
              alt="Dental Doctor"
              width={420}
              height={500}
              style={{
                objectFit: 'cover'
              }}
            />

          </div>

          {/* Floating Card */}

          <div style={{
            position: 'absolute',
            bottom: '40px',
            left: '-40px',
            backdropFilter: 'blur(12px)',
            background: 'rgba(255,255,255,0.85)',
            borderRadius: '16px',
            padding: '16px 20px',
            boxShadow:
              '0 20px 40px rgba(0,0,0,0.12)'
          }}>
            <div style={{
              fontWeight: '800',
              color: '#2563EB',
              fontSize: '26px'
            }}>
              4.9 ⭐
            </div>
            <div style={{
              fontSize: '12px',
              color: '#64748B'
            }}>
              Google Reviews
            </div>
          </div>

        </div>

      </div>

    </section>
  )
}

function Stat({ value, label }) {

  return (

    <div>
      <div style={{
        fontSize: '30px',
        fontWeight: '800',
        color: '#2563EB'
      }}>
        {value}
      </div>

      <div style={{
        fontSize: '13px',
        color: '#94A3B8'
      }}>
        {label}
      </div>
    </div>

  )

}