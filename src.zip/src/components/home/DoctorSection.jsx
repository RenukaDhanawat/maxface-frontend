import Link from 'next/link'

export default function DoctorSection() {
  return (
    <section style={{padding:'80px 24px', background:'white'}}>
      <div style={{maxWidth:'1280px', margin:'0 auto', display:'grid', gridTemplateColumns:'1fr 1fr', gap:'80px', alignItems:'center'}}>

        {/* Doctor Card */}
        <div style={{position:'relative', display:'flex', justifyContent:'center'}}>
         <div style={{
  width:'360px', height:'420px',
  borderRadius:'32px',
  overflow:'hidden',
  boxShadow:'0 40px 80px rgba(29,78,216,0.2)',
  position:'relative'
}}>
  <img
    src="/doctorphoto.jpg"
    alt="Dr. Srinivasa Rao"
    style={{width:'100%', height:'100%', objectFit:'cover'}}
  />
  {/* Blue overlay at bottom */}
  <div style={{
    position:'absolute', bottom:0, left:0, right:0,
    height:'120px',
    background:'linear-gradient(to top, rgba(29,78,216,0.8), transparent)'
  }}/>
  <div style={{
    position:'absolute', bottom:'20px', left:'20px', color:'white'
  }}>
    <div style={{fontWeight:'800', fontSize:'18px'}}>Dr. Srinivasa Rao</div>
    <div style={{fontSize:'13px', opacity:0.9}}>Oral & Maxillofacial Surgeon</div>
  </div>
</div>
          {/* Experience badge */}
          <div style={{
            position:'absolute', bottom:'-10px', right:'20px',
            background:'white', borderRadius:'16px', padding:'16px 24px',
            boxShadow:'0 20px 40px rgba(0,0,0,0.1)', textAlign:'center',
            border:'1px solid #F1F5F9'
          }}>
            <div style={{fontSize:'32px', fontWeight:'900', color:'#1D4ED8', letterSpacing:'-1px'}}>8+</div>
            <div style={{fontSize:'12px', color:'#64748B', fontWeight:'500'}}>Years Experience</div>
          </div>
        </div>

        {/* Doctor Info */}
        <div>
          <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'20px', letterSpacing:'0.5px'}}>
            MEET OUR SPECIALIST
          </div>
          <h2 style={{fontSize:'clamp(28px, 3vw, 44px)', fontWeight:'800', color:'#0F172A', marginBottom:'8px', letterSpacing:'-1px'}}>
            Dr. Srinivasa Rao
          </h2>
          <p style={{fontSize:'16px', color:'#1D4ED8', fontWeight:'600', marginBottom:'20px'}}>
            Oral & Maxillofacial Surgeon — Implantologist
          </p>
          <p style={{fontSize:'15px', color:'#64748B', lineHeight:'1.8', marginBottom:'28px'}}>
            Dr. Srinivasa Rao is one of Bangalore's most trusted dental implant specialists. With expertise in oral surgery, implantology, and anaplastology, he has transformed thousands of smiles with precision and care.
          </p>

          {/* Specializations */}
          <div style={{display:'flex', flexDirection:'column', gap:'10px', marginBottom:'32px'}}>
            {[
              '🦷 Specialist in Dental Implants — Basic to Advanced',
              '🏥 Oral & Maxillofacial Surgery',
              '🎓 Implantology Academy Director',
              '🏅 Anaplastology & Prosthodontics Expert',
            ].map((item) => (
              <div key={item} style={{
                display:'flex', alignItems:'center', gap:'10px',
                background:'#F8FAFC', padding:'12px 16px', borderRadius:'10px',
                fontSize:'14px', color:'#374151', border:'1px solid #F1F5F9'
              }}>
                {item}
              </div>
            ))}
          </div>

          <div style={{display:'flex', gap:'12px'}}>
            <Link href="/appointment" style={{
              background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
              color:'white', padding:'13px 28px', borderRadius:'10px',
              textDecoration:'none', fontWeight:'600', fontSize:'14px',
              boxShadow:'0 4px 12px rgba(29,78,216,0.3)'
            }}>
              Book Consultation
            </Link>
            <Link href="/about" style={{
              background:'white', color:'#1D4ED8', padding:'13px 28px',
              borderRadius:'10px', textDecoration:'none', fontWeight:'600',
              fontSize:'14px', border:'1px solid #DBEAFE'
            }}>
              View Profile →
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}