'use client'
import Link from 'next/link'

const services = [
  { 
    image:'implant.jpeg',
    title:'Dental Implants',
    desc:'Advanced implant solutions from basic to full mouth rehabilitation by certified implantologists.',
    slug:'dental-implants',
    tag:'Speciality'
  },
  {
    image:'endodentic.jpg',
    title:'Endodontics',
    desc:'Pain-free root canal treatments using rotary endodontics in single sitting.',
    slug:'endodontics',
    tag:'Pain Free'
  },
  {
    image:'prostdontic.webp',
    title:'Prosthodontics',
    desc:'Crowns, bridges, dentures and complete prosthetic solutions for missing teeth.',
    slug:'prosthodontics',
    tag:''
  },
  {
    image:'Orthodontics.jpg',
    title:'Orthodontics',
    desc:'Metal braces, ceramic braces and invisible aligners for perfectly aligned teeth.',
    slug:'orthodontics',
    tag:''
  },
  {
    image:'periodontal.webp',
    title:'Periodontics',
    desc:'Comprehensive gum disease treatment and laser periodontal therapy.',
    slug:'periodontics',
    tag:''
  },
  {
    image:'maxillofacial.jpg',
    title:'Maxillofacial Prosthodontics',
    desc:'Specialized anaplastology and facial prosthetics — a unique expertise at Maxface.',
    slug:'maxillofacial-prosthodontics',
    tag:'Unique'
  },
]

export default function ServicesSection() {
  return (
    <section style={{padding:'80px 24px', background:'white'}}>
      <div style={{maxWidth:'1280px', margin:'0 auto'}}>

        {/* Header */}
        <div style={{textAlign:'center', marginBottom:'60px'}}>
          <div style={{display:'inline-block', background:'#EFF6FF', color:'#1D4ED8', padding:'6px 16px', borderRadius:'20px', fontSize:'13px', fontWeight:'600', marginBottom:'16px', letterSpacing:'0.5px'}}>
            OUR SERVICES
          </div>
          <h2 style={{fontSize:'clamp(28px, 4vw, 44px)', fontWeight:'800', color:'#0F172A', marginBottom:'16px', letterSpacing:'-1px'}}>
            Turning Your Smile Into an Experience
          </h2>
          <p style={{fontSize:'16px', color:'#64748B', maxWidth:'500px', margin:'0 auto', lineHeight:'1.7'}}>
            From routine checkups to advanced implant surgeries — all dental treatments under one roof in Bangalore.
          </p>
        </div>

        {/* Grid */}
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(320px, 1fr))', gap:'24px'}}>
          {services.map((service) => (
            <Link key={service.slug} href={`/treatments/${service.slug}`} style={{textDecoration:'none'}}>
              <div style={{
                background:'white', borderRadius:'20px', overflow:'hidden',
                border:'1px solid #F1F5F9', transition:'all 0.3s ease',
                boxShadow:'0 2px 8px rgba(0,0,0,0.04)'
              }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = 'translateY(-8px)'
                  e.currentTarget.style.boxShadow = '0 20px 40px rgba(29,78,216,0.12)'
                  e.currentTarget.style.borderColor = '#DBEAFE'
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'translateY(0)'
                  e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.04)'
                  e.currentTarget.style.borderColor = '#F1F5F9'
                }}
              >
                {/* Image */}
                <div style={{position:'relative', height:'200px', overflow:'hidden'}}>
                  <img
                    src={service.image}
                    alt={service.title}
                    style={{width:'100%', height:'100%', objectFit:'cover', transition:'transform 0.3s ease'}}
                    onMouseEnter={e => e.target.style.transform = 'scale(1.05)'}
                    onMouseLeave={e => e.target.style.transform = 'scale(1)'}
                  />
                  {/* Overlay gradient */}
                  <div style={{
                    position:'absolute', bottom:0, left:0, right:0,
                    height:'60px',
                    background:'linear-gradient(to top, rgba(0,0,0,0.3), transparent)'
                  }}/>
                  {/* Tag */}
                  {service.tag && (
                    <div style={{
                      position:'absolute', top:'12px', right:'12px',
                      background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
                      color:'white', padding:'4px 12px', borderRadius:'20px',
                      fontSize:'11px', fontWeight:'700', letterSpacing:'0.5px'
                    }}>
                      {service.tag}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div style={{padding:'20px'}}>
                  <h3 style={{fontSize:'18px', fontWeight:'700', color:'#0F172A', marginBottom:'8px'}}>
                    {service.title}
                  </h3>
                  <p style={{fontSize:'14px', color:'#64748B', lineHeight:'1.6', marginBottom:'16px'}}>
                    {service.desc}
                  </p>
                  <div style={{display:'flex', alignItems:'center', gap:'6px', color:'#1D4ED8', fontSize:'13px', fontWeight:'600'}}>
                    Learn More
                    <span style={{fontSize:'16px'}}>→</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* View All */}
        <div style={{textAlign:'center', marginTop:'48px'}}>
          <Link href="/treatments" style={{
            display:'inline-block',
            background:'linear-gradient(135deg, #1D4ED8, #0EA5E9)',
            color:'white', padding:'14px 36px', borderRadius:'10px',
            textDecoration:'none', fontWeight:'700', fontSize:'15px',
            boxShadow:'0 4px 12px rgba(29,78,216,0.3)'
          }}>
            View All Treatments →
          </Link>
        </div>

      </div>
    </section>
  )
}