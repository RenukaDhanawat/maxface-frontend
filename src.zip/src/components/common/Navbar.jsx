'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'

const navLinks = [
  { name: 'Home', href: '/' },
  { name: 'About', href: '/about' },
  { name: 'Treatments', href: '/treatments' },
  { name: 'Doctors', href: '/doctor' },
  { name: 'Gallery', href: '/gallery' },
  { name: 'Blog', href: '/blog' },
  { name: 'Contact', href: '/contact' },
]

export default function Navbar() {

  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 30)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav
      style={{
        position: 'fixed',
        top: 0,
        width: '100%',
        zIndex: 100,
        backdropFilter: 'blur(18px)',
        background: scrolled
          ? 'rgba(255,255,255,0.85)'
          : 'rgba(255,255,255,0.95)',
        borderBottom: scrolled
          ? '1px solid rgba(0,0,0,0.06)'
          : '1px solid transparent',
        transition: 'all 0.35s ease'
      }}
    >

      <div
        style={{
          maxWidth: '1300px',
          margin: '0 auto',
          padding: '0 28px',
          height: scrolled ? '64px' : '78px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          transition: 'all 0.35s ease'
        }}
      >

        {/* LOGO */}

        <Link
          href="/"
          style={{
            display: 'flex',
            alignItems: 'center',
            textDecoration: 'none'
          }}
        >

<Image
  src="/logo.svg"
  alt="MaxFace Dental Clinic"
  width={200}
  height={60}
  priority
/>
        </Link>

        {/* DESKTOP NAV */}

        <div
          style={{
            display: 'flex',
            gap: '6px',
            alignItems: 'center'
          }}
        >

          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              style={{
                position: 'relative',
                fontSize: '14px',
                fontWeight: '500',
                color: '#475569',
                padding: '10px 14px',
                borderRadius: '8px',
                textDecoration: 'none',
                transition: 'all 0.25s ease'
              }}

              onMouseEnter={(e) => {
                e.currentTarget.style.color = '#1D4ED8'
              }}

              onMouseLeave={(e) => {
                e.currentTarget.style.color = '#475569'
              }}

            >
              {link.name}
            </Link>
          ))}

        </div>


        {/* RIGHT SECTION */}

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px'
          }}
        >

          {/* PHONE */}

          <a
            href="tel:+919980477725"
            style={{
              fontSize: '13px',
              fontWeight: '600',
              color: '#1D4ED8',
              background: '#EFF6FF',
              padding: '8px 14px',
              borderRadius: '8px',
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            📞 +91 99804 77725
          </a>

          {/* LOGIN */}

          <Link
            href="/portal"
            style={{
              padding: '8px 16px',
              borderRadius: '8px',
              fontSize: '13px',
              fontWeight: '600',
              border: '1px solid #E2E8F0',
              color: '#334155',
              textDecoration: 'none',
              background: 'white'
            }}
          >
            Login
          </Link>

          {/* BOOK APPOINTMENT */}

          <Link
            href="/appointment"
            style={{
              background: 'linear-gradient(135deg,#2563EB,#06B6D4)',
              color: 'white',
              padding: '10px 20px',
              borderRadius: '10px',
              fontSize: '13px',
              fontWeight: '600',
              textDecoration: 'none',
              boxShadow: '0 8px 22px rgba(37,99,235,0.35)',
              transition: 'all 0.25s ease'
            }}

            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)'
              e.currentTarget.style.boxShadow =
                '0 10px 26px rgba(37,99,235,0.45)'
            }}

            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)'
              e.currentTarget.style.boxShadow =
                '0 8px 22px rgba(37,99,235,0.35)'
            }}

          >
            Book Appointment
          </Link>

        </div>

      </div>

    </nav>
  )
}