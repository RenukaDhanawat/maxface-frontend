'use client'
import Link from 'next/link'

export default function Footer() {
  return (
    <footer style={{
      background:'linear-gradient(180deg,#0B1A32,#020617)',
      color:'white',
      padding:'70px 24px 30px'
    }}>
      <div style={{maxWidth:'1200px', margin:'0 auto'}}>

        <div style={{
          display:'grid',
          gridTemplateColumns:'1.4fr 1fr 1fr 1.2fr',
          gap:'50px',
          marginBottom:'50px'
        }}>

        {/* BRAND */}

        <div>

          <p style={{
            color:'#94A3B8',
            fontSize:'15px',
            lineHeight:'1.7',
            maxWidth:'280px',
            marginBottom:'25px'
          }}>
            Maxface Dental Implant & Anaplastology Clinic in Bangalore. 
            Delivering advanced implantology and personalized dental care since 2016.
          </p>

          <div style={{display:'flex', gap:'12px'}}>

            <a href="https://www.facebook.com/profile.php?id=100086378576580"
              style={{
                width:'42px',
                height:'42px',
                background:'#1E293B',
                borderRadius:'12px',
                display:'flex',
                alignItems:'center',
                justifyContent:'center'
              }}>
              <img src="https://cdn.simpleicons.org/facebook/white" width="18"/>
            </a>

            <a href="https://www.instagram.com/maxface.dental/"
              style={{
                width:'42px',
                height:'42px',
                background:'#1E293B',
                borderRadius:'12px',
                display:'flex',
                alignItems:'center',
                justifyContent:'center'
              }}>
              <img src="https://cdn.simpleicons.org/instagram/white" width="18"/>
            </a>

          </div>

        </div>

        {/* TREATMENTS */}

        <div>

          <h4 style={{
            fontSize:'13px',
            letterSpacing:'1px',
            marginBottom:'18px',
            color:'#CBD5F5'
          }}>
            TREATMENTS
          </h4>

          <div style={{display:'flex', flexDirection:'column', gap:'10px'}}>
            {[
              'Dental Implants',
              'Endodontics',
              'Prosthodontics',
              'Orthodontics',
              'Periodontics',
              'Pedodontics'
            ].map(item => (

              <Link key={item}
                href="/treatments"
                style={{
                  color:'#94A3B8',
                  fontSize:'14px',
                  textDecoration:'none'
                }}>
                {item}
              </Link>

            ))}
          </div>

        </div>

        {/* QUICK LINKS */}

        <div>

          <h4 style={{
            fontSize:'13px',
            letterSpacing:'1px',
            marginBottom:'18px',
            color:'#CBD5F5'
          }}>
            QUICK LINKS
          </h4>

          <div style={{display:'flex', flexDirection:'column', gap:'10px'}}>
            <Link href="/" style={{color:'#94A3B8', textDecoration:'none'}}>Home</Link>
            <Link href="/about" style={{color:'#94A3B8', textDecoration:'none'}}>About Us</Link>
            <Link href="/doctor" style={{color:'#94A3B8', textDecoration:'none'}}>Our Doctors</Link>
            <Link href="/gallery" style={{color:'#94A3B8', textDecoration:'none'}}>Gallery</Link>
            <Link href="/blog" style={{color:'#94A3B8', textDecoration:'none'}}>Blog</Link>
            <Link href="/contact" style={{color:'#94A3B8', textDecoration:'none'}}>Contact</Link>
          </div>

        </div>

        {/* CONTACT */}

        <div>

          <h4 style={{
            fontSize:'13px',
            letterSpacing:'1px',
            marginBottom:'18px',
            color:'#CBD5F5'
          }}>
            CONTACT
          </h4>

          <div style={{color:'#94A3B8', fontSize:'14px', lineHeight:'1.7'}}>

            <p style={{marginBottom:'14px'}}>
              📍 Reg No 14/268A, 1st Floor, RS Arcade,<br/>
              2nd Main Road, Kasturi Nagar,<br/>
              Bangalore - 560043
            </p>

            <p style={{marginBottom:'10px'}}>
              📞 +91 98456 55304<br/>
              +91 99804 77725
            </p>

            <p>
              📧 maxface.in@gmail.com
            </p>

          </div>

        </div>

        </div>

        {/* BOTTOM */}

        <div style={{
          borderTop:'1px solid #1E293B',
          paddingTop:'20px',
          display:'flex',
          justifyContent:'space-between',
          flexWrap:'wrap',
          gap:'10px'
        }}>

          <p style={{color:'#64748B', fontSize:'13px'}}>
            © 2026 Maxface Dental Implant & Anaplastology Clinic
          </p>

          <div style={{display:'flex', gap:'18px'}}>
            <span style={{color:'#64748B', fontSize:'13px'}}>Privacy Policy</span>
            <span style={{color:'#64748B', fontSize:'13px'}}>Terms</span>
          </div>

        </div>

      </div>
    </footer>
  )
}