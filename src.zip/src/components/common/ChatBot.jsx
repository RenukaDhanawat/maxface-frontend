'use client'
import { useState } from 'react'

export default function ChatBot() {
  const [isOpen,   setIsOpen]   = useState(false)
  const [messages, setMessages] = useState([
    { role:'assistant', text:'👋 Hi! I am MaxFace AI Assistant. How can I help you today? Ask me about treatments, appointments, or any dental concerns!' }
  ])
  const [input,    setInput]    = useState('')
  const [loading,  setLoading]  = useState(false)

  const sendMessage = async () => {
    if (!input.trim() || loading) return
    const userMessage = input.trim()
    setInput('')
    setMessages(prev => [...prev, { role:'user', text:userMessage }])
    setLoading(true)

    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514',
          max_tokens:1000,
          messages:[{
            role:'user',
            content:`You are a helpful dental assistant for MaxFace Dental Clinic in Mumbai. Answer questions about dental treatments, symptoms, appointment booking, and oral health. Keep answers concise, friendly and professional. Clinic info: Phone: +91 12345 67890, Timings: Mon-Sat 9AM-8PM. Patient question: ${userMessage}`
          }]
        })
      })
      const data = await response.json()
      const reply = data.content?.[0]?.text || "Sorry, please call us at +91 12345 67890."
      setMessages(prev => [...prev, { role:'assistant', text:reply }])
    } catch {
      setMessages(prev => [...prev, { role:'assistant', text:"Sorry, please call us at +91 12345 67890 for assistance." }])
    }
    setLoading(false)
  }

  const handleKey = (e) => {
    if (e.key === 'Enter') { e.preventDefault(); sendMessage() }
  }

  return (
    <>
      {isOpen && (
        <div style={{
          position:'fixed', bottom:'100px', right:'24px', zIndex:1000,
          width:'360px', height:'500px', background:'white', borderRadius:'24px',
          boxShadow:'0 20px 60px rgba(0,0,0,0.15)', display:'flex',
          flexDirection:'column', border:'1px solid #E5E7EB', overflow:'hidden'
        }}>
          {/* Header */}
          <div style={{background:'linear-gradient(135deg, #3B9EFF, #2563EB)', padding:'16px 20px', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
            <div style={{display:'flex', alignItems:'center', gap:'10px'}}>
              <div style={{width:'40px', height:'40px', background:'rgba(255,255,255,0.2)', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'20px'}}>🤖</div>
              <div>
                <div style={{color:'white', fontWeight:'700', fontSize:'15px'}}>MaxFace AI</div>
                <div style={{color:'rgba(255,255,255,0.8)', fontSize:'12px'}}>● Online</div>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} style={{background:'rgba(255,255,255,0.2)', border:'none', color:'white', width:'32px', height:'32px', borderRadius:'50%', cursor:'pointer', fontSize:'16px'}}>✕</button>
          </div>

          {/* Messages */}
          <div style={{flex:1, overflowY:'auto', padding:'16px', display:'flex', flexDirection:'column', gap:'12px'}}>
            {messages.map((msg, i) => (
              <div key={i} style={{display:'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start'}}>
                <div style={{
                  maxWidth:'80%', padding:'12px 16px', borderRadius:'16px', fontSize:'14px', lineHeight:'1.5',
                  background: msg.role === 'user' ? 'linear-gradient(135deg, #3B9EFF, #2563EB)' : '#F3F4F6',
                  color: msg.role === 'user' ? 'white' : '#1A1A2E',
                  borderBottomRightRadius: msg.role === 'user' ? '4px' : '16px',
                  borderBottomLeftRadius: msg.role === 'user' ? '16px' : '4px',
                }}>
                  {msg.text}
                </div>
              </div>
            ))}
            {loading && (
              <div style={{display:'flex', justifyContent:'flex-start'}}>
                <div style={{background:'#F3F4F6', padding:'12px 16px', borderRadius:'16px', borderBottomLeftRadius:'4px', fontSize:'20px'}}>⏳</div>
              </div>
            )}
          </div>

          {/* Quick Questions */}
          <div style={{padding:'8px 16px', display:'flex', gap:'8px', overflowX:'auto'}}>
            {['Book appointment', 'Tooth pain', 'Implant cost'].map(q => (
              <button key={q} onClick={() => setInput(q)} style={{background:'#EFF6FF', color:'#3B9EFF', border:'none', padding:'6px 12px', borderRadius:'20px', fontSize:'12px', fontWeight:'600', cursor:'pointer', whiteSpace:'nowrap'}}>
                {q}
              </button>
            ))}
          </div>

          {/* Input */}
          <div style={{padding:'12px 16px', borderTop:'1px solid #E5E7EB', display:'flex', gap:'8px', alignItems:'center'}}>
            <input
              value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey}
              placeholder="Type your question..."
              style={{flex:1, padding:'10px 14px', borderRadius:'50px', border:'2px solid #E5E7EB', fontSize:'14px', outline:'none', background:'#F9FAFB'}}
            />
            <button onClick={sendMessage} disabled={loading} style={{width:'40px', height:'40px', borderRadius:'50%', background:'linear-gradient(135deg, #3B9EFF, #2563EB)', border:'none', color:'white', fontSize:'16px', cursor: loading ? 'not-allowed' : 'pointer'}}>
              ➤
            </button>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <button onClick={() => setIsOpen(!isOpen)} style={{
        position:'fixed', bottom:'24px', right:'24px', zIndex:1000,
        width:'64px', height:'64px', borderRadius:'50%',
        background:'linear-gradient(135deg, #3B9EFF, #2563EB)',
        border:'none', color:'white', fontSize:'28px', cursor:'pointer',
        boxShadow:'0 8px 24px rgba(59,158,255,0.4)',
        display:'flex', alignItems:'center', justifyContent:'center'
      }}>
        {isOpen ? '✕' : '🤖'}
      </button>
    </>
  )
}